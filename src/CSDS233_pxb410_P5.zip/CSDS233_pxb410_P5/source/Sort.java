package CSDS233_pxb410_P5.source;

/**
 * @author parvbhardwaj
 * This is the sort class which contains different sorting algorithms.
 * The algorithms will also be compared using the Java Timer Class.
 */

import java.util.Arrays;
import java.util.Random;
import java.util.Timer;

public class Sort {
    public void insertionSort(int[] arr, int length) {
        for (int i = 1; i < length; i++) {
            if (arr[i] < arr[i - 1]) {
                int toInsert = arr[i];
                int j = i;
                while (j > 0 && toInsert < arr[j - 1]) {
                    arr[j] = arr[j - 1];
                    j = j - 1;
                }
                arr[j] = toInsert;
            }
        }
    }

    public void quickSort(int[] array) {
        int low = array[0];
        int high = array[array.length - 1];

        quickSort(array, low, high);

    }


    private void quickSort(int arr[], int low, int high)
    {
        if (low < high)
        {
			/* pi is partitioning index, arr[pi] is
			now at right place */
            int pi = partition(arr, low, high);

            // Recursively sort elements before
            // partition and after partition
            quickSort(arr, low, pi-1);
            quickSort(arr, pi+1, high);
        }
    }

    private int partition(int arr[], int low, int high) {
        int pivot = arr[high];
        int i = (low - 1); // index of smaller element
        for (int j = low; j < high; j++) {
            // If current element is smaller than or
            // equal to pivot
            if (arr[j] <= pivot) {
                i++;

                // swap arr[i] and arr[j]
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }

        // swap arr[i+1] and arr[high] (or pivot)
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;

        return i + 1;
    }

    public void mergeSort(int[] array) {

    }

    /***
     *
     * @param n n of ints that need to be in the array
     * @param a the starting bound
     * @param b the ending bound
     * @return returns an int array
     */
    public int[] randomArray(int n , int a, int b) {
        int randIArray[] = new int[n + 2];
        randIArray[0]  = a;
        randIArray[randIArray.length-1]  = b;
        Random randi = new Random();
        for(int i =1; i < randIArray.length-1; i++){
            int  randInt = randi.nextInt(b);

            randIArray[i] = randInt;

        }
        return randIArray;

    }

    // Extra credit sorting Algo: Bubble Sort
    public static void main(String args[]) {
        Sort randIArray = new Sort();
        int randIArr[] = randIArray.randomArray(11, 1  ,10);
        System.out.println(Arrays.toString(randIArr));
        long startTime = System.nanoTime();
        long endTime = System.nanoTime();
        long duration = endTime = startTime;



    }

}
